package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.*;

import java.util.List;

public interface OrderService {
    /**
     * 分页查询
     *
     * @param orderFrom
     * @param page
     * @param limit
     * @return
     */
    Page<OrderFrom> selectPage(OrderFrom orderFrom, int page, int limit);

    /**
     * 分页查询
     *
     * @param orderDetails
     * @return
     */
    List<OrderDetails> selectPage(OrderDetails orderDetails);

    /**
     * 新增
     *
     * @param orderFrom
     * @return
     */
    boolean insert(OrderFrom orderFrom);

    /**
     * 删除
     */
    boolean delById(String id);

    /**
     * 删除
     */
    boolean delTolleyById(String id);

    /**
     * 编辑
     */
    boolean edit(OrderFrom orderFrom);

    /**
     * 结算方法
     */
    boolean settle(String ids, String nums, Float price, Address address ,String mode, String content);

    /**
     * 购买方法
     *
     * @param productId
     * @param number
     * @param address
     * @return
     */
    boolean sale(String productId, String number, Address address,String mode,String content);
    /**
     * 生成订单方法
     *
     */
    boolean sale(String productId, String number, String address,String mode,String content);
    /**
     * 支付方法
     */
    boolean toPay(String id);

    /**
     * 提醒发货
     */
    boolean remind(String orderId);

    /**
     * 得到信息
     */
    List<Logistics> getRemind(String orderId, String type);

    /**
     * 删除信息
     */
    boolean deleteRemind(String orderId);

    /**
     * 添加物流信息
     */
    boolean addLogistics(String orderId, String content);

    /**
     * 评价
     *
     * @param orderId
     * @param content
     * @return
     */
    boolean addEvaluate(String orderId, String content, String score);
    /**
     * 商品好评率
     */
    Float favorable(String productId);

    /**
     * 退款
     *
     * @param orderId
     * @param content
     * @return
     */
    boolean salesReturn(String orderId, String content);

    /**
     * 退款分页查询
     *
     * @param salesReturn
     * @param page
     * @param limit
     * @return
     */
    Page<SalesReturn> selectPage(SalesReturn salesReturn, int page, int limit);

    /**
     * 删除
     */
    boolean delSalesById(String id, String orderId);

    List<Evaluate> getEvaluateList(String productId);


    Product getProductBytrolleyId(String id);


    OrderFrom getOrderFrom(String id);

    List<OrderDetails> getOrderDetailsByProductId(String productId);
    /**
     * 获取订单数
     */
    Integer getOrderNumber();
    /**
     * 获取成交金额
     */
    Float getZumPrice();

}
