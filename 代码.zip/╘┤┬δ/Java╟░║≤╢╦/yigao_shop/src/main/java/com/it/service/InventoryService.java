package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Inventory;
import com.it.entity.OutInventory;

import java.util.List;

public interface InventoryService {
    /**
     * 分页查询
     *
     * @param inventory
     * @param page
     * @param limit
     * @return
     */
    Page<Inventory> selectPage(Inventory inventory, int page, int limit);

    /**
     * 出库信息
     *
     * @param outInventory
     * @param page
     * @param limit
     * @return
     */
    Page<OutInventory> selectPage(OutInventory outInventory, int page, int limit);

    /**
     * 新增
     *
     * @param inventory
     * @return
     */
    boolean insert(Inventory inventory);
    boolean insert(OutInventory outInventory);

    /**
     * 删除
     */
    boolean delById(String id);
    /**
     * 删除
     */
    boolean delOutInventoryById(String id);

    /**
     * 编辑
     *
     * @param inventory
     * @return
     */
    boolean edit(Inventory inventory);

    /**
     * 得到单个对象
     */
    Inventory getOneById(String id);

    /**
     * 得到单个对象
     */
    List<Inventory> getOneByProductuuId(String productuuId);

    List<Inventory> getOneByProductId(String productId);

    /**
     * 修改库存数目
     */
    boolean editStock(String productId, Integer number);

}
