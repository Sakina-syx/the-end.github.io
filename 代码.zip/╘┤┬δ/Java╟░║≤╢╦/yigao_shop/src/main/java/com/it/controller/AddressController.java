package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Address;
import com.it.service.AddressService;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈用户收货地址实现接口〉<br>
 *
 * @author
 * @create 2019/1/16 16:00
 * @since 1.0.0
 */
@Controller
@RequestMapping("/address")
public class AddressController {
    @Autowired
    private AddressService addressService;
    @Autowired
    private ItdragonUtils itdragonUtils;


    /**
     * 收货地址列表加载接口
     *
     * @param address
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("addressTable.do")
    public TableResultResponse classifyTable(Address address, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        address.setUserId(itdragonUtils.getSessionUser().getId());
        Page<Address> pageInfo = addressService.selectPage(address, page, limit);
        for (Address record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("address", record.getCityPicker() + record.getDetailAddress());
            resultMap.put("tel", record.getPhone());
            resultMap.put("username", record.getConsignee());
            resultMap.put("default", record.getIsDefault());
            if ("1".equals(record.getIsDefault())) {
                resultMap.put("isDefault", "默认地址");
            } else {
                resultMap.put("isDefault", "");
            }

            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 删除收货地址
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/address.do")
    public ResultResponse delClassify(String id) {
        boolean result = addressService.delById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 新增收货地址
     *
     * @param address
     * @return
     */
    @ResponseBody
    @PostMapping("/address.do")
    public ResultResponse insertClassify(Address address) {
        address.setUserId(itdragonUtils.getSessionUser().getId());
        boolean result = addressService.insert(address);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 编辑收货地址
     *
     * @param address
     * @return
     */
    @ResponseBody
    @PutMapping("/address.do")
    public ResultResponse updataClassify(Address address) {
        boolean result = addressService.edit(address);
        if (!result) {
            return Result.resuleError("编辑失败");
        }
        return Result.resuleSuccess();
    }

}