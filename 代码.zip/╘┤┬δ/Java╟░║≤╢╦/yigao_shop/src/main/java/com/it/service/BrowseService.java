package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Address;
import com.it.entity.BrowseRecord;

import java.util.List;

public interface BrowseService {

    boolean insert(String userId,String productId);

    List<BrowseRecord>  getList();
}
