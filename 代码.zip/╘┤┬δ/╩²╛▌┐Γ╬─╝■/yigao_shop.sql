/*
SQLyog Professional v12.09 (64 bit)
MySQL - 5.7.24-log : Database - yigao_shop
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`yigao_shop` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `yigao_shop`;

/*Table structure for table `gm_address` */

DROP TABLE IF EXISTS `gm_address`;

CREATE TABLE `gm_address` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `cityPicker` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `detailAddress` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `consignee` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `isDefault` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_address` */

insert  into `gm_address`(`id`,`userId`,`cityPicker`,`detailAddress`,`consignee`,`phone`,`isDefault`) values ('0db69246fba64172ba1b7aebff98d9e7','8d8652b6a51844d1a9e31c55d5b6ffc8','广东省/深圳市/南山区','世界之窗1号','刘先生','13788889999','1'),('17eff0228c7b4d518d01c35bd0e25768','bbc63577a6b044b3b65b19217b25c527','江西省/景德镇市/浮梁县','xxx','张三','18977445566','1'),('abf7b5c476ff4c4380493945ca626b76','2','北京市/北京市/东城区','测试111','李先生','13788889999','1'),('e8e1456e143144109a9a9a787866e1ad','1','北京市/北京市/东城区','a','张三','18977445566','1');

/*Table structure for table `gm_answering` */

DROP TABLE IF EXISTS `gm_answering`;

CREATE TABLE `gm_answering` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `content` longtext COLLATE utf8_bin,
  `time` datetime DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `userImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `leaveId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_answering` */

/*Table structure for table `gm_browserecord` */

DROP TABLE IF EXISTS `gm_browserecord`;

CREATE TABLE `gm_browserecord` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `productId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `time` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `frequency` int(11) DEFAULT NULL,
  `userId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_browserecord` */

insert  into `gm_browserecord`(`id`,`productId`,`time`,`frequency`,`userId`) values ('02b1af6dcd1e42119ce006cfe20e7d05','2c8cc25d019e4197a15f8bb845c25011','20230918100942',2,'fccaf99a5b724536b7511ce97b92fcd7'),('3570cace36774fe7b353848c8eba03fa','ea9f223fecd54949bb9d9811ec55f774','20231023101024',3,'1'),('65813304f2274b8c8e58096ecf25ea38','2c8cc25d019e4197a15f8bb845c25011','20200410100411',4,'bbc63577a6b044b3b65b19217b25c527'),('6fd4850ff9b649229da1787e827244b8','1e3c1228cc2d4ada966e4b9acfb27ccf','20230918100919',3,'1'),('9cb9c9664eed45a19b80b74b46caa957','1e3c1228cc2d4ada966e4b9acfb27ccf','20230918100946',2,'fccaf99a5b724536b7511ce97b92fcd7'),('ba1a57ded0874e0ba058725b5eaf27b6','2c8cc25d019e4197a15f8bb845c25011','20231023111019',21,'1'),('c7a53b76e6f049fb9acce21b5adb3a03','ea9f223fecd54949bb9d9811ec55f774','20231023121051',2,'2'),('c812429d1f7e4d61b1a04cf168f856d5','2c8cc25d019e4197a15f8bb845c25011','20230712110717',8,'8d8652b6a51844d1a9e31c55d5b6ffc8'),('eadf0546e5f94997885d5e3a6661935a','2c8cc25d019e4197a15f8bb845c25011','20230712100745',3,'2');

/*Table structure for table `gm_chdclassify` */

DROP TABLE IF EXISTS `gm_chdclassify`;

CREATE TABLE `gm_chdclassify` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `ptId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_chdclassify` */

insert  into `gm_chdclassify`(`id`,`name`,`ptId`) values ('5b44af9049ac449cb261bca937bad444','奶酪黄油','1abf91473e60448a8efe43c18630501c'),('659c0395125b4b8188b234f94ff0fee9','低温奶','1abf91473e60448a8efe43c18630501c'),('70b7430ee3ea49ada096ffdfbcf697c7','低糖','1abf91473e60448a8efe43c18630501c'),('9df6e122b32249a4baee9c1b92303723','山东苹果','2ff261c7bd304ac69d738ea5fdc12e99'),('b6a62dc963c247f6b9649c0e5bacb19c','榴莲','00b88c8af822429da1d4d31c1e77667b');

/*Table structure for table `gm_classify` */

DROP TABLE IF EXISTS `gm_classify`;

CREATE TABLE `gm_classify` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_classify` */

insert  into `gm_classify`(`id`,`name`) values ('00b88c8af822429da1d4d31c1e77667b','蛋糕'),('1abf91473e60448a8efe43c18630501c','奥利奥'),('2ff261c7bd304ac69d738ea5fdc12e99','水果'),('71c87b2bbca9425c95ee23672baa10e3','盼盼');

/*Table structure for table `gm_collect` */

DROP TABLE IF EXISTS `gm_collect`;

CREATE TABLE `gm_collect` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `productId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `productName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productPrice` float DEFAULT NULL,
  `userId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `productImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_collect` */

insert  into `gm_collect`(`id`,`productId`,`productName`,`productPrice`,`userId`,`productImg`) values ('2747f1ea8ece481997b0fbb9d86ead43','2c8cc25d019e4197a15f8bb845c25011','A款心心相印 8英寸',128,'fccaf99a5b724536b7511ce97b92fcd7','/image/5ac5e40fNca2fec12.jpg'),('85f1dcb6869f439d9e1791a2ebc21733','2c8cc25d019e4197a15f8bb845c25011','A款心心相印 8英寸',128,'8d8652b6a51844d1a9e31c55d5b6ffc8','/image/5ac5e40fNca2fec12.jpg'),('b6d53ae1880743a3a6fd63a2bc006c9b','2c8cc25d019e4197a15f8bb845c25011','A款心心相印 8英寸',128,'bbc63577a6b044b3b65b19217b25c527','/image/5ac5e40fNca2fec12.jpg');

/*Table structure for table `gm_evaluate` */

DROP TABLE IF EXISTS `gm_evaluate`;

CREATE TABLE `gm_evaluate` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `img` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `content` longtext COLLATE utf8_bin,
  `score` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_evaluate` */

insert  into `gm_evaluate`(`id`,`userName`,`img`,`productId`,`content`,`score`,`time`) values ('61f285832f174c76ae28919bfbf5189f','user11','/image/u=190217322,1383310850&fm=26&gp=0.jpg','2c8cc25d019e4197a15f8bb845c25011','aaaa','5','2020-04-10 22:07:05');

/*Table structure for table `gm_inventory` */

DROP TABLE IF EXISTS `gm_inventory`;

CREATE TABLE `gm_inventory` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `productId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `hasPin` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `unitPrice` float DEFAULT NULL,
  `totalPrice` float DEFAULT NULL,
  `productName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productUuid` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orderNum` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `content` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_inventory` */

insert  into `gm_inventory`(`id`,`productId`,`hasPin`,`stock`,`unitPrice`,`totalPrice`,`productName`,`productUuid`,`time`,`userName`,`orderNum`,`content`) values ('603af6f30bd4488c8cc4fdcae3f84dd8','1e3c1228cc2d4ada966e4b9acfb27ccf',0,50,14.9,745,'苹果','APPL126133584','2023-09-18 22:26:13','admin','APPL126133584_001','苹果入库'),('aad78ad5c8164446abb574be3b77db47','2c8cc25d019e4197a15f8bb845c25011',5,5,128,1280,'A款心心相印 8英寸','IBSA204334013','2020-04-10 22:02:27','admin','10066','a'),('f080e5d3c6164e52b68410a4a962076f','ea9f223fecd54949bb9d9811ec55f774',0,50,188,9400,'千层榴莲蛋糕','L202032346572','2023-07-14 00:54:02','admin','L202032346572','榴莲蛋糕入库');

/*Table structure for table `gm_leaveword` */

DROP TABLE IF EXISTS `gm_leaveword`;

CREATE TABLE `gm_leaveword` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `content` longtext COLLATE utf8_bin,
  `time` datetime DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `userImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_leaveword` */

insert  into `gm_leaveword`(`id`,`content`,`time`,`userName`,`userImg`) values ('2dbe086d48f94f488bf672f5c9c46dd1','aa','2020-04-10 22:03:47','user11','/image/u=190217322,1383310850&fm=26&gp=0.jpg');

/*Table structure for table `gm_likenumber` */

DROP TABLE IF EXISTS `gm_likenumber`;

CREATE TABLE `gm_likenumber` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `leaveId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_likenumber` */

/*Table structure for table `gm_log` */

DROP TABLE IF EXISTS `gm_log`;

CREATE TABLE `gm_log` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `operation` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_log` */

insert  into `gm_log`(`id`,`userName`,`operation`,`time`) values ('4e4c966bbcfb4a9fa7ba8e85e99463b5','admin','前台登录操作','2023-10-23 12:44:11'),('6c129272332d40a994e258fc0143cb4e','admin','前台登录操作','2023-10-23 11:53:53'),('77210d752b5f4900a33b78b3d3fc8e34','user1','前台登录操作','2023-10-23 12:47:23'),('943cb279682844e1b5511fb04ca14ee5','admin','前台登录操作','2023-10-23 12:04:11'),('b5fb6397d914416893a88a8d3ef2e1f5','admin','前台登录操作','2023-10-23 11:47:23'),('cfa4ec902814418c99703934c3868d52','admin','前台登录操作','2023-10-23 12:39:17'),('d28a0321a92349168e838d05e9241c39','admin','前台登录操作','2023-10-23 12:03:34'),('d4245713c62e408ba6d68e4096a7821f','admin','前台登录操作','2023-10-23 11:59:49'),('dc316e4a72f94ca29de3d1a0a171a8d3','admin','前台登录操作','2023-10-23 11:50:50'),('ff634ea6fcfd4c17802ffe79e9e7eef0','liujiahao','前台登录操作','2023-10-23 12:56:16');

/*Table structure for table `gm_logistics` */

DROP TABLE IF EXISTS `gm_logistics`;

CREATE TABLE `gm_logistics` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `orderId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `content` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_logistics` */

insert  into `gm_logistics`(`id`,`orderId`,`content`,`type`,`time`) values ('3d5b842953564bfa897ba8ebba2f6a16','bf0e721db1764d308de6e108b8967b8b','aa','logistics','2020-04-10 22:06:40');

/*Table structure for table `gm_news` */

DROP TABLE IF EXISTS `gm_news`;

CREATE TABLE `gm_news` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `categoryId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `categoryName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `content` longtext COLLATE utf8_bin,
  `img` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `digest` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_news` */

/*Table structure for table `gm_newscategory` */

DROP TABLE IF EXISTS `gm_newscategory`;

CREATE TABLE `gm_newscategory` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_newscategory` */

/*Table structure for table `gm_orderdetails` */

DROP TABLE IF EXISTS `gm_orderdetails`;

CREATE TABLE `gm_orderdetails` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `orderId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `productName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productPrice` float DEFAULT NULL,
  `productImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productParam` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productNum` int(11) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_orderdetails` */

insert  into `gm_orderdetails`(`id`,`orderId`,`productName`,`productPrice`,`productImg`,`productParam`,`productNum`,`status`,`productId`) values ('8404161c6bb542d3a64d13c37da6799d','4d74237bfb7a438e9f515e5519b7656b','A款心心相印 8英寸',115.2,'/image/5ac5e40fNca2fec12.jpg','口味：原味店铺： 沃赞食品旗舰店商品毛重：1.0kg',1,'0','2c8cc25d019e4197a15f8bb845c25011'),('98aa9f4d25bc46fdbefca76cfe0ff027','bf0e721db1764d308de6e108b8967b8b','A款心心相印 8英寸',128,'/image/5ac5e40fNca2fec12.jpg','口味：原味,店铺： 沃赞食品旗舰店,商品毛重：1.0kg',1,'1','2c8cc25d019e4197a15f8bb845c25011'),('a343fb80593f483d8ef576a8d30fc7c6','cac33f35de164c179412043392c22bdc','A款心心相印 8英寸',128,'/image/5ac5e40fNca2fec12.jpg','口味：原味,店铺： 沃赞食品旗舰店,商品毛重：1.0kg',1,'0','2c8cc25d019e4197a15f8bb845c25011'),('e69aed847716439b8ad3e85b1469713e','a83eeb3f38b543afb437b058a4ba2454','A款心心相印 8英寸',128,'/image/5ac5e40fNca2fec12.jpg','口味：原味店铺： 沃赞食品旗舰店商品毛重：1.0kg',2,'0','2c8cc25d019e4197a15f8bb845c25011');

/*Table structure for table `gm_orderfrom` */

DROP TABLE IF EXISTS `gm_orderfrom`;

CREATE TABLE `gm_orderfrom` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `price` float DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uuId` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `mode` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `content` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_orderfrom` */

insert  into `gm_orderfrom`(`id`,`userId`,`address`,`price`,`time`,`status`,`uuId`,`mode`,`content`) values ('4d74237bfb7a438e9f515e5519b7656b','2','地址:北京市/北京市/东城区测试111  李先生 13788889999',115.2,'2023-06-15 21:49:10','未付款','1000002030262578','物流','测试'),('a83eeb3f38b543afb437b058a4ba2454','8d8652b6a51844d1a9e31c55d5b6ffc8','地址:广东省/深圳市/南山区世界之窗1号  刘先生 13788889999',256,'2023-07-12 23:26:24','未付款','1000001219984670','物流','测试111'),('bf0e721db1764d308de6e108b8967b8b','bbc63577a6b044b3b65b19217b25c527','地址:江西省/景德镇市/浮梁县xxx  张三 18977445566',128,'2020-04-10 22:05:34','交易完成','1000000389603379','快递','尽快发货'),('cac33f35de164c179412043392c22bdc','8d8652b6a51844d1a9e31c55d5b6ffc8','地址:广东省/深圳市/南山区世界之窗1号  刘先生 13788889999',128,'2023-07-12 11:34:14','未付款','1000000546964268','物流','榴莲千层');

/*Table structure for table `gm_outinventory` */

DROP TABLE IF EXISTS `gm_outinventory`;

CREATE TABLE `gm_outinventory` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `productName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productUuid` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `unitPrice` float DEFAULT NULL,
  `totalPrice` float DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_outinventory` */

insert  into `gm_outinventory`(`id`,`productName`,`productUuid`,`number`,`unitPrice`,`totalPrice`,`time`,`userName`) values ('0182da761beb4a729e22910ed44fd623','A款心心相印 8英寸','IBSA204334013',1,128,128,'2020-04-10 22:05:34','user11'),('6bbc406a21e9471e8fdd6cc77554b56a','A款心心相印 8英寸','IBSA204334013',1,128,128,'2023-07-12 11:34:14','liujiahao'),('9f913f328f0b49a0b56fb4c18deef2c5','A款心心相印 8英寸','IBSA204334013',1,128,128,'2023-06-15 21:49:10','user1'),('a812401414d846a6ac83c47b6ad8e26b','A款心心相印 8英寸','IBSA204334013',2,128,256,'2023-07-12 23:26:24','liujiahao');

/*Table structure for table `gm_permission` */

DROP TABLE IF EXISTS `gm_permission`;

CREATE TABLE `gm_permission` (
  `permissionId` varchar(36) NOT NULL,
  `permissionName` varchar(255) NOT NULL,
  `permissionMark` varchar(255) DEFAULT NULL,
  `permissionType` varchar(255) DEFAULT NULL,
  `parentId` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `available` int(11) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `lastTime` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `gm_permission` */

insert  into `gm_permission`(`permissionId`,`permissionName`,`permissionMark`,`permissionType`,`parentId`,`url`,`priority`,`available`,`createTime`,`lastTime`,`description`) values ('3','系统管理','menu:sysSet','menu','0',NULL,5,1,'2023-08-06 15:22:50','2017-10-03 15:22:50','&#x265f;'),('5','资源管理','menu:sysSet:org:org','menu','3','/menu/menuManagerHouse.do',0,1,'2023-08-02 15:22:50','2018-01-22 11:39:03','&#x2709;'),('6','角色管理','menu:sysSet:module:module:module','menu','3','/module/moduleManagerHouse.do',30,1,'2023-08-03 15:22:50','2018-01-22 11:38:43','&#x2709;'),('7','用户管理','menu:sysSet:user:user','menu','3','/user/userManagerHouse.do',5,1,'2023-08-01 15:22:50','2020-01-01 16:23:30','&#x2709;'),('4','日志管理','menu:sysSet:log','menu','3','/log/index.do',NULL,1,'2023-08-04 15:22:50',NULL,'layui-icon'),('8','网站设置','menu:info','menu','0',NULL,NULL,1,'2023-08-05 15:22:50',NULL,'&#x2709;'),('9','首页轮播图','menu:info:lunBo','menu','8','/wbeSet/slideshow.do',NULL,1,'2023-08-05 15:22:50',NULL,'layui-icon'),('10','商城信息维护','menu:info:wbeParameter','menu','8','/wbeSet/wbeParameter.do',NULL,1,'2023-08-06 15:22:50',NULL,'layui-icon'),('11','商品分类','menu:info:classify','menu','17','/classify/index.do',NULL,1,'2023-08-01 15:22:50',NULL,'layui-icon'),('12','留言管理','menu:operation','menu','0',NULL,NULL,1,'2023-08-04 15:22:50',NULL,'&#x265b;'),('13','在线留言','menu:operation:leaveWord','menu','12','/leaveWord/index.do',NULL,1,'2023-08-01 15:22:50',NULL,'layui-icon'),('17','商品管理','menu:product','menu','0',NULL,NULL,1,'2023-08-02 15:22:50',NULL,'&#x272a;'),('18','商品列表','menu:product:index','menu','17','/product/index.do',NULL,1,'2023-08-01 15:24:50',NULL,'layui-icon'),('19','新增商品','menu:product:add','menu','17','/product/addProduct.do',NULL,1,'2023-08-01 15:23:50',NULL,'layui-icon'),('20','库存管理','menu:product:inventory','menu','17','/inventory/index.do',NULL,1,'2023-08-01 15:25:50',NULL,'layui-icon'),('21','订单管理','menu:afterSale','menu','0',NULL,NULL,1,'2023-08-03 15:22:50',NULL,'&#x2709;'),('22','订单列表','menu:afterSale:order','menu','21','/order/index.do',NULL,1,'2023-08-01 15:21:50',NULL,'layui-icon'),('23','退货管理','menu:afterSale:return','menu','21','/order/salesReturnPage.do',NULL,1,'2023-08-01 15:22:50',NULL,'layui-icon'),('24','数据统计','menu:statistics','menu','0',NULL,NULL,1,'2023-08-01 15:22:50',NULL,'&#x2709;'),('25','销量统计','menu:statistics:sale','menu','24','/statistics/sale.do',NULL,1,'2023-07-01 14:22:50',NULL,'layui-icon'),('26','出库信息','menu:product:out','menu','17','/inventory/outInventoryIndex.do',NULL,1,'2023-08-01 15:26:50',NULL,'layui-icon');

/*Table structure for table `gm_product` */

DROP TABLE IF EXISTS `gm_product`;

CREATE TABLE `gm_product` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `uuId` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `img` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `price` float DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `parameter` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `particulars` longtext COLLATE utf8_bin,
  `classifyId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `chdClassId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_product` */

insert  into `gm_product`(`id`,`uuId`,`name`,`img`,`price`,`createTime`,`discount`,`parameter`,`particulars`,`classifyId`,`chdClassId`) values ('1e3c1228cc2d4ada966e4b9acfb27ccf','APPL126133584','苹果','/image/apples.jpg',14.9,'2023-09-18 22:15:24',0.8,'a,b','新鲜的山东苹果','2ff261c7bd304ac69d738ea5fdc12e99','9df6e122b32249a4baee9c1b92303723'),('2c8cc25d019e4197a15f8bb845c25011','IBSA204334013','A款心心相印 8英寸','/image/5ac5e40fNca2fec12.jpg',128,'2020-04-10 22:02:06',0.9,'口味：原味,店铺： 沃赞食品旗舰店,商品毛重：1.0kg','<ul class=\"parameter2 p-parameter-list\" style=\"padding-top: 20px; padding-bottom: 15px; list-style: none; overflow: hidden; color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255);\"><img alt=\"\" class=\"\" src=\"https://img14.360buyimg.com/popWaterMark/jfs/t1/9732/30/3554/109525/5bd71b03Ef01edaeb/65d66d2661f4d094.jpg\" style=\"border-width: 0px; border-style: initial;\"><br><img alt=\"\" class=\"\" src=\"http://img30.360buyimg.com/popWareDetail/jfs/t9685/286/1424665922/157191/35942c2a/59e0c4d8Nd53dbcc2.jpg\" style=\"border-width: 0px; border-style: initial;\"><br><br><br><img alt=\"\" class=\"\" src=\"http://img30.360buyimg.com/popWareDetail/jfs/t10378/143/1432957410/103808/62be3cac/59e0c9d7Ne69f8e80.jpg\" style=\"border-width: 0px; border-style: initial;\"></ul>','1abf91473e60448a8efe43c18630501c','5b44af9049ac449cb261bca937bad444'),('ea9f223fecd54949bb9d9811ec55f774','L202032346572','千层榴莲蛋糕','/image/榴莲千层1.jpeg',188,'2023-07-14 00:53:19',0.9,'口味：原味,店铺： 沃赞食品旗舰店,商品毛重：1.0kg','<p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">天猫榴莲西施旗舰店，榴莲西施榴莲千层400g2盒+1戚风蛋糕日常售价为119.9元，下单领取50元优惠券，到手价为69.9元。</p><p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">6寸榴莲西施榴莲千层蛋糕400g*2+巧克力戚风蛋糕210g*1，多层果肉，层层爆浆。</p><p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">甄选A+级榴莲果肉，果肉含量≥40%，金黄饱满，满口留香。</p><p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">品牌：榴莲西施</p><p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">品名：榴莲千层蛋糕</p><p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">规格：6寸/400g</p><p style=\"margin-bottom: 0px; padding-top: 15px; padding-bottom: 15px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, &quot;PingFang SC&quot;, &quot;HanHei SC&quot;, SimHei, Arial, sans-serif, SimSuncss; font-size: 16px; background-color: rgb(255, 255, 255);\">保质期：210天</p><p style=\"text-align: center;\"><img src=\"/image/ab802c07-1870-4dad-865d-fcb6da9e5152.jpg\"></p>','00b88c8af822429da1d4d31c1e77667b','b6a62dc963c247f6b9649c0e5bacb19c');

/*Table structure for table `gm_role` */

DROP TABLE IF EXISTS `gm_role`;

CREATE TABLE `gm_role` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `role` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_role` */

insert  into `gm_role`(`id`,`role`,`description`) values ('1','管理员','所拥有权限由管理员决定'),('2','用户',NULL);

/*Table structure for table `gm_role_permission` */

DROP TABLE IF EXISTS `gm_role_permission`;

CREATE TABLE `gm_role_permission` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `roleId` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `permissionId` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=792 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_role_permission` */

insert  into `gm_role_permission`(`id`,`roleId`,`permissionId`) values (768,'1','8'),(769,'1','9'),(770,'1','10'),(771,'1','11'),(772,'1','12'),(773,'1','13'),(774,'1','14'),(775,'1','15'),(776,'1','16'),(777,'1','17'),(778,'1','18'),(779,'1','19'),(780,'1','20'),(781,'1','26'),(782,'1','21'),(783,'1','22'),(784,'1','23'),(785,'1','24'),(786,'1','25'),(787,'1','3'),(788,'1','5'),(789,'1','6'),(790,'1','7'),(791,'1','4');

/*Table structure for table `gm_salesreturn` */

DROP TABLE IF EXISTS `gm_salesreturn`;

CREATE TABLE `gm_salesreturn` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orderId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `orderUuId` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_salesreturn` */

/*Table structure for table `gm_slideshow` */

DROP TABLE IF EXISTS `gm_slideshow`;

CREATE TABLE `gm_slideshow` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `imgUrl` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `creationTime` datetime DEFAULT NULL,
  `creationUser` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_slideshow` */

insert  into `gm_slideshow`(`id`,`imgUrl`,`creationTime`,`creationUser`) values ('1b8065b8ef324e25bedf089a91f7ec73','/image/f62d99910d532687505a7bab0f0abbce.jpeg','2023-07-12 12:09:59','admin'),('6e0fa783eb9b46828a3cedee9428f113','/image/8957bf8ea5a772162bbe180d2710263f.jpg','2020-04-10 21:54:46','admin'),('f28bab1c04ce455480b3e63be7f30003','/image/榴莲千层1.jpeg','2023-07-12 12:09:52','admin');

/*Table structure for table `gm_trolley` */

DROP TABLE IF EXISTS `gm_trolley`;

CREATE TABLE `gm_trolley` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `productName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productPrice` float DEFAULT NULL,
  `productImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productParam` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `productNum` int(11) DEFAULT NULL,
  `productId` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_trolley` */

insert  into `gm_trolley`(`id`,`userId`,`productName`,`productPrice`,`productImg`,`productParam`,`productNum`,`productId`) values ('4530fbf3f0004bb6a469849a92df1052','2','千层榴莲蛋糕',169.2,'/image/榴莲千层1.jpeg','口味：原味店铺： 沃赞食品旗舰店商品毛重：1.0kg',1,'ea9f223fecd54949bb9d9811ec55f774'),('5be2a608b5f848ecb9eca4a9714d4a71','fccaf99a5b724536b7511ce97b92fcd7','A款心心相印 8英寸',128,'/image/5ac5e40fNca2fec12.jpg','口味：原味店铺： 沃赞食品旗舰店商品毛重：1.0kg',1,'2c8cc25d019e4197a15f8bb845c25011'),('bd9bf26c55574dffa279b91dfe749917','bbc63577a6b044b3b65b19217b25c527','A款心心相印 8英寸',128,'/image/5ac5e40fNca2fec12.jpg','口味：原味店铺： 沃赞食品旗舰店商品毛重：1.0kg',1,'2c8cc25d019e4197a15f8bb845c25011');

/*Table structure for table `gm_user` */

DROP TABLE IF EXISTS `gm_user`;

CREATE TABLE `gm_user` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `userName` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `salt` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `iphone` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `platform` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '0表示已删除',
  `realName` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `imgUrl` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `balance` float(255,0) DEFAULT NULL,
  `payPass` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `bankCard` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `userRank` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_user` */

insert  into `gm_user`(`id`,`userName`,`password`,`salt`,`iphone`,`email`,`platform`,`createdDate`,`updatedDate`,`status`,`realName`,`sex`,`address`,`imgUrl`,`balance`,`payPass`,`bankCard`,`userRank`) values ('1','admin','admin','','18966554411','115@qq.com',NULL,'2018-10-24 17:07:35','2023-10-23 12:44:11',1,'超级管理员','女','广东省深圳市','/image/girl-portrait.jpeg',80,'123',NULL,'0'),('2','user1','123456',NULL,'15877445566','395651006@qq.com',NULL,'2019-12-23 01:02:24','2023-10-23 12:47:23',1,'李2','女','北京','/image/timg (2).jpg',400,'456','2727222896000072274','1'),('24f5372012774486b53ea5d9d0dc662e','user3','123456',NULL,'15877445566','1156326165@qq.com',NULL,'2020-01-09 19:04:45','2020-01-09 19:04:57',1,'李','男','北京','/image/017e-ikyziqw7074235.jpg',0,'123',NULL,'0'),('7df6b836190a41bcb6b259042d97b955','user2','123456',NULL,'15877445566','1156326165@qq.com',NULL,'2020-01-09 18:09:39','2020-01-09 19:04:21',1,'李','男','北京','/image/da6f5ef9bc0a617bca6d1ecafb29ee1d.jpg',0,'123',NULL,'0'),('8d8652b6a51844d1a9e31c55d5b6ffc8','liujiahao','123456',NULL,'13788889999','13788889999@163.com',NULL,'2023-06-21 20:17:27','2023-10-23 12:56:16',1,'刘嘉豪','男','湖北省武汉市江夏佛祖岭街道','/image/boy-portrait.jpeg',10000,'123','4456498654654654651','0'),('bbc63577a6b044b3b65b19217b25c527','user11','123456',NULL,'15877445566','11563265@qq.com',NULL,'2020-04-10 22:02:55','2023-09-17 22:19:22',1,'李','女','xx省mm市ss街道','/image/u=190217322,1383310850&fm=26&gp=0.jpg',872,'123','6301051997456261655','0'),('fccaf99a5b724536b7511ce97b92fcd7','user01','123456',NULL,'13128216612','chaoshi@qq.com',NULL,'2023-09-18 22:01:19','2023-09-18 22:01:28',1,'陈先生','男','广州天河区上社1号','/image/timg (1).jpg',0,'123',NULL,'0');

/*Table structure for table `gm_user_role` */

DROP TABLE IF EXISTS `gm_user_role`;

CREATE TABLE `gm_user_role` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `userId` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `roleId` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_user_role` */

insert  into `gm_user_role`(`id`,`userId`,`roleId`) values (72,'1','1'),(74,'b81886e0f04048ebb44fcdbc765ffda5','2'),(76,'7df6b836190a41bcb6b259042d97b955','2'),(77,'24f5372012774486b53ea5d9d0dc662e','2'),(78,'bbc63577a6b044b3b65b19217b25c527','2'),(79,'8d8652b6a51844d1a9e31c55d5b6ffc8','2'),(80,'fccaf99a5b724536b7511ce97b92fcd7','2');

/*Table structure for table `gm_wbeparameter` */

DROP TABLE IF EXISTS `gm_wbeparameter`;

CREATE TABLE `gm_wbeparameter` (
  `id` varchar(36) COLLATE utf8_bin NOT NULL,
  `logo` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `hotNumber` int(11) DEFAULT NULL,
  `newNumber` int(11) DEFAULT NULL,
  `recommendOne` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `recommendTwo` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `recommendThree` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `bottomImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `iphone` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `aboutWe` longtext COLLATE utf8_bin,
  `backgroundImg` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `year` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `copyright` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `yu` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `threshold` varchar(255) COLLATE utf8_bin DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `gm_wbeparameter` */

insert  into `gm_wbeparameter`(`id`,`logo`,`hotNumber`,`newNumber`,`recommendOne`,`recommendTwo`,`recommendThree`,`bottomImg`,`iphone`,`aboutWe`,`backgroundImg`,`name`,`year`,`copyright`,`yu`,`code`,`threshold`) values ('1','购物商城',8,8,'底部推荐语1','底部推荐语2','底部推荐语3','/image/u=4120536008,2179725559&fm=26&gp=0.jpg','530-1600543','<div style=\"margin-top: 8px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255); width: 80px; float: left; font-weight: bold; letter-spacing: 1px; text-align: right;\"><p class=\"\" style=\"margin-bottom: 0px; padding-bottom: 28px;\">会员群体：</p><p style=\"margin-bottom: 0px; padding-top: 17px;\">品牌信用：</p><p style=\"margin-bottom: 0px; padding-top: 17px;\">品牌包装：</p><p style=\"margin-bottom: 0px; padding-top: 46px; padding-bottom: 29px;\">商业统计：</p><p style=\"margin-bottom: 0px; padding-top: 17px;\">视觉团队：</p></div><div class=\"\" style=\"margin-bottom: 20px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255); width: 797px; float: right; line-height: 30px;\">唯品会的会员群体是为数众多的年轻人群、白领群体以及&nbsp;<br>名牌爱好者。通过各类有针对性的营销手法，唯品会目前已经积累了一定的用户基础。&nbsp;<br>可利用站内所经营的品牌优势，树立品牌信用，扩大品牌影响力，并针对不同受众进行品牌特卖，增强网站会员凝聚力。&nbsp;<br>唯品会配有专业团队为品牌作包装宣传：设计团队为品牌制作形象展示动画，编辑团队以品牌故事及品牌资讯在“时尚会”作文字推广，客服团队每周进行品牌知识培训，把品牌信息带给消费者，加深其对品牌的印象。&nbsp;<br>唯品会拥有专业的商业数据统计系统，品牌售卖结束后，会把全方位的统计数据（包括热销款式、客户群体分布状况、地区售卖情况、消费者反响等）反馈给品牌合作商，为其市场战略提供有价值的参考。&nbsp;<br>我们有专业拍摄、设计及制作团队，由专业资深人员把关，通过富有表现力的商品图片，充分展示各名牌商品的品牌意韵及特点。</div><p class=\"\" style=\"margin-bottom: 0px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255);\"><img class=\"\" src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_07.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom;\"></p><p class=\"\" style=\"margin-bottom: 0px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255); text-indent: 25px; line-height: 25px;\">尊敬的商家，无论您的品牌是国际名牌还是中国名牌，或者已获得中国驰名商标、国家免检产品等称号，唯品会都诚意邀请您与我们携手合作。您的公司必须是具备法人资格的合法经营的公司或企业，且至少具备以下资格之一：</p><div class=\"\" style=\"color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255); width: 266px; float: left;\"><div class=\"\" style=\"margin-top: 19px; clear: both; height: 28px;\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_l.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"><div class=\"\" style=\"background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" vipzs_list_m.gif\")=\"\" left=\"\" center=\"\" repeat-x;=\"\" width:=\"\" 190px;=\"\" height:=\"\" 28px;=\"\" line-height:=\"\" float:=\"\" left;\"=\"\">•著名/知名品牌的生产商</div><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_r.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"></div><div style=\"margin-top: 19px; clear: both; height: 28px;\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_l.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"><div class=\"\" style=\"background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" vipzs_list_m.gif\")=\"\" left=\"\" center=\"\" repeat-x;=\"\" width:=\"\" 190px;=\"\" height:=\"\" 28px;=\"\" line-height:=\"\" float:=\"\" left;\"=\"\">•著名/知名品牌的授权总代理商</div><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_r.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"></div><div style=\"margin-top: 19px; clear: both; height: 28px;\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_l.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"><div class=\"\" style=\"background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" vipzs_list_m.gif\")=\"\" left=\"\" center=\"\" repeat-x;=\"\" width:=\"\" 190px;=\"\" height:=\"\" 28px;=\"\" line-height:=\"\" float:=\"\" left;\"=\"\">•著名/知名品牌的授权总经销商</div><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_r.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"></div><div style=\"margin-top: 19px; clear: both; height: 28px;\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_l.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"><div class=\"\" style=\"background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" vipzs_list_m.gif\")=\"\" left=\"\" center=\"\" repeat-x;=\"\" width:=\"\" 190px;=\"\" height:=\"\" 28px;=\"\" line-height:=\"\" float:=\"\" left;\"=\"\">•著名/知名品牌的分公司</div><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_r.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"></div><div style=\"margin-top: 19px; clear: both; height: 28px;\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_l.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"><div class=\"\" style=\"background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" vipzs_list_m.gif\")=\"\" left=\"\" center=\"\" repeat-x;=\"\" width:=\"\" 190px;=\"\" height:=\"\" 28px;=\"\" line-height:=\"\" float:=\"\" left;\"=\"\">•著名/知名品牌的分支机构</div><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_r.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"></div><div style=\"margin-top: 19px; clear: both; height: 28px;\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_l.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"><div class=\"\" style=\"background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" vipzs_list_m.gif\")=\"\" left=\"\" center=\"\" repeat-x;=\"\" height:=\"\" 28px;=\"\" line-height:=\"\" float:=\"\" left;\"=\"\">•著名/知名国际品牌驻中国的办事处</div><img class=\"\" src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_list_r.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom; float: left;\"></div></div><div class=\"\" style=\"margin-bottom: 30px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255); width: 613px; float: left;\"><h1 class=\"\" style=\"margin-top: 22px; font-size: 12px;\">需提供的资料：</h1><div style=\"margin-top: 9px; clear: both;\"><div class=\"\" style=\"padding: 15px 20px; width: 562px; height: 120px; background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" bg_txt2.png\");=\"\" line-height:=\"\" 1.7em;\"=\"\">• 供应商全称，如：XX有限公司；&nbsp;<br>• 请提供：公司简介、公司网址、公司实体店面位置、供应商级别（品牌方、总代理、区域代理、省级代理等）经营商品类别（男装、女装、家居等）、相关资质证明；&nbsp;<br>• 联络方式：联络人、联系电话、邮箱（请提供非腾讯邮箱，避免漏收邮件）、地址等；&nbsp;<br>• 是否可开具增值税发票；&nbsp;<br>注：若您的邮件在五个工作日内未得到回复，可反馈至&nbsp;<a class=\"\" href=\"mailtfeedback@vipshop.com\" style=\"color: rgb(51, 51, 51);\">feedback@vipshop.com</a>&nbsp;，我们将立即为您处理。</div><div style=\"clear: both;\"></div></div><h1 class=\"\" style=\"margin-top: 18px; font-size: 12px;\">请详细提供以上资料并与我们联系，唯品会愿与您共同创造电子商务的美好明天！</h1><div style=\"margin-top: 9px; clear: both;\"><div class=\"\" style=\"padding: 15px 20px; width: 562px; height: 100px; background: url(\" ugc.vipstatic.com=\"\" img=\"\" support=\"\" 1=\"\" investment=\"\" bg_txt.png\");=\"\" line-height:=\"\" 1.7em;\"=\"\">招商邮箱：&nbsp;<a href=\"mailtbrand@vipshop.com\" style=\"color: rgb(51, 51, 51);\">brand@vipshop.com</a>&nbsp;<br>MP开放商家平台部邮箱：&nbsp;<a href=\"mailtmp@vipshop.com\" style=\"color: rgb(51, 51, 51);\">mp@vipshop.com</a>&nbsp;<br>传真：020-22330164（只接受传真）&nbsp;<br>地址：广州市荔湾区花海街20号唯品会（醉观公园旁） &nbsp;&nbsp;邮编：510370</div><div style=\"clear: both;\"></div></div></div><p class=\"\" style=\"margin-bottom: 30px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255);\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_25.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom;\"></p><p style=\"margin-bottom: 50px; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255);\"><img src=\"https://ugc.vipstatic.com/img/support/1/investment/vipzs_29.gif\" style=\"border-width: 0px; border-style: initial; vertical-align: bottom;\"></p>','/image/u=2980514782,1164839498&fm=26&gp=0.jpg','购物商城','2020-2021','ItYuYao','localhost:9001/indexWbe','v2020 pro','10');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
