package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Address;

public interface AddressService {
    /**
     * 分页查询
     *
     * @param address
     * @param page
     * @param limit
     * @return
     */
    Page<Address> selectPage(Address address, int page, int limit);

    /**
     * 新增
     *
     * @param address
     * @return
     */
    boolean insert(Address address);

    /**
     * 删除
     */
    boolean delById(String id);

    /**
     * 编辑
     */
    boolean edit(Address address);

    /**
     * 查询默认地址
     */
    Address getAddress(String userId);


}
