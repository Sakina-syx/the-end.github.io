package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 库存实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_inventory")
public class Inventory implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 商品id
     */
    private String productId;
    /**
     * 商品名称
     */
    private String productName;
    /**
     * 商品uuId
     */
    private String productUuid;
    /**
     * 已销数量
     */
    private Integer hasPin;
    /**
     * 库存数量
     */
    private Integer stock;
    /**
     * 单价
     */
    private float unitPrice;
    /**
     * 合计
     */
    private float totalPrice;
    /**
     * 时间
     */
    private String time;
    /**
     * 入库人
     */
    private String userName;
    /**
     * 入库订单
     */
    private String orderNum;
    /**
     * 备注
     */
    private String content;

}