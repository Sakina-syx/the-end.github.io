package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 购物车实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_trolley")
public class Trolley implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 用户id
     */
    private String userId;
    /**
     * 商品名称
     */
    private String productId;
    private String productName;
    /**
     * 商品价格
     */
    private Float productPrice;
    /**
     * 商品图片
     */
    private String productImg;
    /**
     * 商品参数
     */
    private String productParam;
    /**
     * 商品数目
     */
    private Integer productNum;


}