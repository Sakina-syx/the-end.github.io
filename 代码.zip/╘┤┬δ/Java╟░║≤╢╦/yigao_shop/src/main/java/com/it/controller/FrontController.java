package com.it.controller;


import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.*;
import com.it.service.*;
import com.it.util.ItdragonUtils;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @version:
 * @Description: 前台页面相关内容
 * @author:
 * @date: 2019年8月16日 上午10:09:18
 */
@RequestMapping("/front")
@Controller
public class FrontController {
    private static final transient Logger log = LoggerFactory.getLogger(FrontController.class);

    @Autowired
    private SlideshowService slideshowService;
    @Autowired
    private WbeParameterService wbeParameterService;
    @Autowired
    private ClassifyService classifyService;
    @Autowired
    private LeaveWordService leaveWordService;
    @Autowired
    private NewsCategoryService newsCategoryService;
    @Autowired
    private NewsService newsService;
    @Autowired
    private ItdragonUtils itdragonUtils;
    @Autowired
    private UserService userService;
    @Autowired
    private ProductService productService;
    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private AddressService addressService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private BrowseService browseService;

    @RequestMapping("/test.do")
    public void test() throws Exception {
        List<BrowseRecord> browseRecordList = browseService.getList();
        Date dt = new Date();
        SimpleDateFormat matter1 = new SimpleDateFormat("yyyyMMddhhMMss");
        String date = matter1.format(dt);
        String path = itdragonUtils.writeToD(date, browseRecordList);
        System.out.println(path);
        List<String> slopeOneCF = itdragonUtils.getSlopeOneCF("1", path, productService.getProductList());
        System.out.println(slopeOneCF);
    }

    /**
     * 前台首页跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView index(ModelAndView mv) {
        //首页轮播图集合
        List<Slideshow> slideshowList = slideshowService.getList();
        mv.addObject("slideshowList", slideshowList);
        //查询新品推荐,热销推荐参数
        WbeParameter wbeParameter = wbeParameterService.getWbeParameter();
        //拿到商品列表按时间排序
        List<Product> productListOrderByTime = productService.getProductListOrderByTime();
        if (productListOrderByTime.size() <= Integer.parseInt(wbeParameter.getNewNumber())) {
            mv.addObject("productListOrderByTime", productListOrderByTime);
        } else {
            mv.addObject("productListOrderByTime", productListOrderByTime.subList(0, Integer.parseInt(wbeParameter.getNewNumber())));
        }
        List<Product> productListOrderSlae = productService.getProductListOrderSlae();
        if (productListOrderByTime.size() <= Integer.parseInt(wbeParameter.getHotNumber())) {
            mv.addObject("productListOrderSlae", productListOrderSlae);
        } else {
            mv.addObject("productListOrderSlae", productListOrderSlae.subList(0, Integer.parseInt(wbeParameter.getHotNumber())));
        }
        CommonMethods("index", mv);
        mv.setViewName("/front/index");
        return mv;
    }

    /**
     * 猜你喜欢页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/likeList.do")
    public ModelAndView likeList(ModelAndView mv) throws Exception {
        List<BrowseRecord> browseRecordList = browseService.getList();
        Date dt = new Date();
        SimpleDateFormat matter1 = new SimpleDateFormat("yyyyMMddhhMMss");
        String date = matter1.format(dt);
        String path = itdragonUtils.writeToD(date, browseRecordList);
        System.out.println(path);
        List<String> slopeOneCF = itdragonUtils.getSlopeOneCF(itdragonUtils.getSessionUser().getId(), path, productService.getProductList());
        System.out.println(slopeOneCF);
        List<Product> resultList = new ArrayList<>();
        for (String s : slopeOneCF) {
            Product product = productService.getOne(s);
            if (product != null) {
                resultList.add(product);
            }
        }
        if (resultList.isEmpty()) {
            //如果推荐集合为空
            mv.addObject("message", "由于您数据基数较少,暂时无法为您推荐商品");
        } else {
            mv.addObject("message", "yes");


        }
        mv.addObject("resultList", resultList);
        CommonMethods("likeList", mv);
        mv.setViewName("/front/likeList");
        return mv;
    }

    /**
     * 关于我们页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/aboutWe.do")
    public ModelAndView aboutWe(ModelAndView mv) {
        CommonMethods("aboutWe", mv);
        mv.setViewName("/front/aboutWe");
        return mv;
    }

    /**
     * 搜索页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/search.do")
    public ModelAndView search(ModelAndView mv, String searchParam) {
        CommonMethods("no", mv);
        Product product = new Product();
        product.setName(searchParam);
        Page<Product> productPage = productService.selectPage(product, 1, 1000);
        mv.addObject("productList", productPage.getRecords());
        mv.setViewName("/front/search");
        return mv;
    }

    /**
     * 在线留言页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/leaveWord.do")
    public ModelAndView leaveWord(ModelAndView mv) {
        CommonMethods("leaveWord", mv);
        //获取留言内容
        List<LeaveWord> leaveWordList = leaveWordService.selectList();
        for (LeaveWord leaveWord : leaveWordList) {
            //将留言下的回复存放入leaveWord对象中
            List<Answering> answerings = leaveWordService.selectListAnswering(leaveWord.getId());
            leaveWord.setAnsweringList(answerings);
            leaveWord.setCount(answerings.size());
            //拿到该留言的点赞数并且封装到likeCount属性中
            leaveWord.setLikeCount(leaveWordService.getLikeNumber(leaveWord.getId()));
        }
        mv.addObject("leaveWordList", leaveWordList);
        mv.setViewName("/front/leaveWord");
        return mv;
    }

    /**
     * 新闻资讯页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/news.do")
    public ModelAndView news(ModelAndView mv, Integer page, Integer limit, String categoryId) {
        //系统默认当前页码,条数
        if (page == null) {
            page = 1;
        }
        if (limit == null) {
            limit = 5;
        }
        CommonMethods("news", mv);
        //获取新闻分类
        List<NewsCategory> categoryList = newsCategoryService.selectList();
        mv.addObject("categoryList", categoryList);
        News news = new News();
        news.setCategoryId(categoryId);
        //当前分页默认
        Page<News> selectPage = newsService.selectPage(news, page, limit);
        mv.addObject("newsPage", selectPage);
        //将前台传入的页数传回前台
        mv.addObject("page", page);
        //将前台传入的分类id传回前台
        mv.addObject("categoryId", categoryId);
        mv.setViewName("/front/news");
        return mv;
    }

    /**
     * 新闻详情页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/newDetail.do")
    public ModelAndView newDetail(ModelAndView mv, String id) {
        News news = newsService.getOneById(id);
        mv.addObject("newsOne", news);
        CommonMethods("news", mv);
        mv.setViewName("/front/newDetail");
        return mv;
    }

    /**
     * 商品列表页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/productList.do")
    public ModelAndView productList(ModelAndView mv, String classifyId) {
        List<ChdClassify> chdClassifyList = classifyService.selectChdClassifyList(classifyId);
        mv.addObject("chdClassifyList", chdClassifyList);
        //父分类信息
        Classify classify = classifyService.getClassify(classifyId);
        mv.addObject("classify", classify);
        CommonMethods("productList", mv);
        mv.setViewName("/front/productList");
        return mv;
    }

    /**
     * 商品详情页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/productDetails.do")
    public ModelAndView productDetails(ModelAndView mv, String id) {
        //增加浏览记录
        browseService.insert(itdragonUtils.getSessionUser().getId(), id);
        Product product = productService.getOne(id);
        //判断该商品是不是收藏
        product.setCollect(productService.isCollect(id));
        //将参数拆分
        product.setParameters(product.getParameter().split(","));
        //拿到库存数
        List<Inventory> inventoryList = inventoryService.getOneByProductuuId(product.getUuId());
        if (inventoryList.isEmpty()) {
            product.setInventoryData(0);
        } else {
            product.setInventoryData(inventoryList.get(0).getStock());
        }
        //拿到该商品下的评价
        List<Evaluate> evaluateList = orderService.getEvaluateList(id);
        mv.addObject("evaluateList", evaluateList);
        mv.addObject("evaluateListNum", evaluateList.size());
        mv.addObject("product", product);
        mv.addObject("good", orderService.favorable(id));
        mv.addObject("chdClassName", classifyService.getChdClassify(product.getChdClassId()).getName());
        CommonMethods("productList", mv);
        mv.setViewName("/front/productDetails");
        return mv;
    }

    /**
     * 个人中心页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/perCenter.do")
    public ModelAndView perCenter(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/perCenter");
        mv.addObject("perCenterActive", "active");
        return mv;
    }

    /**
     * 安全设置页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/security.do")
    public ModelAndView security(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/security");
        mv.addObject("securityActive", "active");
        return mv;
    }

    /**
     * 账号余额页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/balanceInfo.do")
    public ModelAndView balanceInfo(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/balanceInfo");
        mv.addObject("balanceInfoActive", "active");
        return mv;
    }

    /**
     * 地址管理页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/address.do")
    public ModelAndView address(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/address");
        mv.addObject("addressActive", "active");
        return mv;
    }

    /**
     * 新增地址管理页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/insertAddress.do")
    public ModelAndView insertAddress(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/insertAddress");
        return mv;
    }

    /**
     * 我的收藏页面
     *
     * @param mv
     * @return
     */
    @RequestMapping("/collect.do")
    public ModelAndView collect(ModelAndView mv, Integer page, Integer limit) {
        //系统默认当前页码,条数
        if (page == null) {
            page = 1;
        }
        if (limit == null) {
            limit = 12;
        }
        //当前分页默认
        Page<Collect> selectPage = productService.selectCollectPage(null, page, limit);
        mv.addObject("collectPage", selectPage);
        //将前台传入的页数传回前台
        mv.addObject("page", page);
        CommonMethods("no", mv);
        mv.setViewName("/front/collect");
        mv.addObject("collectActive", "active");
        return mv;
    }

    /**
     * 删除收藏
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/collect.do")
    public ResultResponse delCollect(String id) {
        boolean result = productService.delCollectById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 新增收藏
     *
     * @param collect
     * @return
     */
    @ResponseBody
    @PostMapping("/collect.do")
    public ResultResponse addCollect(Collect collect) {
        boolean result = productService.insertCollect(collect);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 加入购物车
     *
     * @param number
     * @param productId
     * @return
     */
    @ResponseBody
    @PostMapping("/inTrolley.do")
    public ResultResponse inTrolley(String productId, String number) {
        //通过商品id查询商品信息
        Product productInfo = productService.getOne(productId);
        Trolley trolley = new Trolley();
        trolley.setProductImg(productInfo.getImg());
        trolley.setProductName(productInfo.getName());
        String parameter = productInfo.getParameter();
        String productParam = "";
        String[] split = parameter.split(",");
        for (String s : split) {
            try {
                productParam += s.split(":")[1] + " ";
            } catch (ArrayIndexOutOfBoundsException e) {
                productParam += s;
            }
        }
        trolley.setProductParam(productParam);
        trolley.setProductId(productId);
        trolley.setProductNum(Integer.parseInt(number));
        //判断用户等级
        if ("0".equals(userService.selectByPrimaryKey(itdragonUtils.getSessionUser().getId()).getUserRank())) {
            trolley.setProductPrice(productInfo.getPrice());
        } else {
            trolley.setProductPrice(productInfo.getPrice() * productInfo.getDiscount());
        }
        boolean result = productService.insertTrolley(trolley);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 购物车页面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/trolley.do")
    public ModelAndView trolley(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/trolley");
        return mv;
    }

    /**
     * 购物车数据表格加载接口
     *
     * @return
     */
    @ResponseBody
    @GetMapping("trolleyTable.do")
    public TableResultResponse trolleyTable() {
        List<Map<String, Object>> infoList = new ArrayList<>();
        List<Trolley> trolleyList = productService.getTrolleyList(itdragonUtils.getSessionUser().getId());
        for (Trolley record : trolleyList) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("name", record.getProductName());
            resultMap.put("avatar", record.getProductImg());
            resultMap.put("price", record.getProductPrice());
            resultMap.put("color", record.getProductParam());
            resultMap.put("number", record.getProductNum());
            if (inventoryService.getOneByProductId(record.getProductId()).isEmpty()) {
                resultMap.put("inventory", 0);
            } else {
                resultMap.put("inventory", inventoryService.getOneByProductId(record.getProductId()).get(0).getStock());
            }

            infoList.add(resultMap);
        }
        return Result.tableResule(0, infoList);
    }

    /**
     * 购买提交订单
     *
     * @param mv
     * @return
     */
    @RequestMapping("/subSettle.do")
    public ModelAndView subSettle(ModelAndView mv, String ids, String nums, String zumPrice) {
        mv.addObject("ids", ids);
        mv.addObject("nums", nums);
        mv.addObject("zumPrice", zumPrice);
        //拿到用户物流信息
        Address address = addressService.getAddress(itdragonUtils.getSessionUser().getId());
        CommonMethods("no", mv);
        mv.addObject("address", address);
        mv.setViewName("/subOrder/settle");
        return mv;
    }

    /**
     * 结算功能
     *
     * @param ids
     * @param nums
     * @return
     */
    @ResponseBody
    @PostMapping("/settleAccounts.do")
    public ResultResponse settleAccounts(String ids, String nums, Float price, String mode, String content) {
        if (!ItdragonUtils.stringIsNotBlack(ids)) {
            return Result.resuleError("请选择要提交的商品!");
        }
        //查询用户是否有默认地址
        Address address = addressService.getAddress(itdragonUtils.getSessionUser().getId());
        if (address == null) {
            return Result.resuleError("请先添加默认地址!");
        }
        //判断每个商品是否超出库存//平且扣除库存
        for (int i = 0; i < ids.split(",").length; i++) {
            Product product = orderService.getProductBytrolleyId(ids.split(",")[i]);
            int stock = 0;
            List<Inventory> inventoryList = inventoryService.getOneByProductId(product.getId());
            if (!inventoryList.isEmpty()) {
                stock = inventoryList.get(0).getStock();
            }
            if (Integer.parseInt(nums.split(",")[i]) > stock) {
                return Result.resuleError("商品:" + productService.getOne(product.getId()).getName() + "  库存不足!");
            } else {
                //生成出库信息
                OutInventory outInventory = new OutInventory();
                outInventory.setProductName(product.getName());
                outInventory.setProductUuid(product.getUuId());
                outInventory.setNumber(Integer.parseInt(nums.split(",")[i]));
                outInventory.setTotalPrice(product.getPrice() * Float.parseFloat(nums.split(",")[i]));
                outInventory.setUnitPrice(product.getPrice());
                inventoryService.insert(outInventory);
                //修改库存
                inventoryService.editStock(product.getId(), Integer.parseInt(nums.split(",")[i]));
            }
        }
        boolean settle = orderService.settle(ids, nums, price, address, mode, content);
        if (settle) {
            return Result.resuleSuccess();
        } else {
            return Result.resuleError("提交失败!");
        }


    }

    /**
     * 删除购物车功能
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/delTrolley.do")
    public ResultResponse delTrolley(String id) {
        boolean settle = orderService.delTolleyById(id);
        if (settle) {
            return Result.resuleSuccess();
        } else {
            return Result.resuleError("提交失败!");
        }


    }

    /**
     * 购买提交订单
     *
     * @param mv
     * @return
     */
    @RequestMapping("/subSale.do")
    public ModelAndView subSale(ModelAndView mv, String productId, String number) {
        mv.addObject("productId", productId);
        mv.addObject("number", number);
        //拿到用户物流信息
        Address address = addressService.getAddress(itdragonUtils.getSessionUser().getId());
        CommonMethods("no", mv);
        mv.addObject("address", address);
        //拿到金额
        Product product = productService.getOne(productId);
        User user = userService.selectByPrimaryKey(itdragonUtils.getSessionUser().getId());
        if ("1".equals(user.getUserRank())) {
            mv.addObject("zumPrice", product.getPrice() * product.getDiscount() * Float.valueOf(number));
        } else {
            mv.addObject("zumPrice", product.getPrice() * Float.valueOf(number));
        }
        mv.setViewName("/subOrder/sale");
        return mv;
    }

    /**
     * 购买功能
     *
     * @param productId
     * @param number
     * @return
     */
    @ResponseBody
    @PostMapping("/sale.do")
    public ResultResponse sale(String productId, String number, String mode, String content) {
        Product product = productService.getOne(productId);
        //查询用户是否有默认地址
        Address address = addressService.getAddress(itdragonUtils.getSessionUser().getId());
        if (address == null) {
            return Result.resuleError("请先添加默认地址!");
        }
        boolean settle = orderService.sale(productId, number, address, mode, content);
        if (settle) {
            inventoryService.editStock(productId, Integer.parseInt(number));
            //生成出库信息
            OutInventory outInventory = new OutInventory();
            outInventory.setProductName(product.getName());
            outInventory.setProductUuid(product.getUuId());
            outInventory.setNumber(Integer.parseInt(number));
            outInventory.setTotalPrice(product.getPrice() * Float.parseFloat(number));
            outInventory.setUnitPrice(product.getPrice());
            inventoryService.insert(outInventory);
            return Result.resuleSuccess();
        } else {
            return Result.resuleError("提交失败!");
        }


    }

    /**
     * 订单中心
     *
     * @param mv
     * @return
     */
    @RequestMapping("/order.do")
    public ModelAndView order(ModelAndView mv) {
        CommonMethods("no", mv);
        mv.setViewName("/front/order");
        mv.addObject("orderActive", "active");
        return mv;
    }

    /**
     * 订单数据表格加载接口
     *
     * @return
     */
    @ResponseBody
    @GetMapping("orderTable.do")
    public TableResultResponse orderTable(OrderFrom orderFrom) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        orderFrom.setUserId(itdragonUtils.getSessionUser().getId());
        Page<OrderFrom> selectPage = orderService.selectPage(orderFrom, 1, 1000);
        for (OrderFrom record : selectPage.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("userId", record.getUserId());
            resultMap.put("address", record.getAddress());
            resultMap.put("price", record.getPrice());
            resultMap.put("status", record.getStatus());
            resultMap.put("mode", record.getMode());
            resultMap.put("timestamp", record.getTime() == null ? "" : record.getTime().substring(0, 19));
            resultMap.put("orderid", record.getUuId());
            infoList.add(resultMap);
        }
        return Result.tableResule(0, infoList);
    }

    /**
     * 订单详情
     *
     * @param mv
     * @return
     */
    @RequestMapping("/orderDetails.do")
    public ModelAndView order(ModelAndView mv, String orderId) {
        CommonMethods("no", mv);
        mv.addObject("orderId", orderId);
        mv.setViewName("/front/orderDetails");
        return mv;
    }

    /**
     * 订单详情数据表格加载接口
     *
     * @return
     */
    @ResponseBody
    @GetMapping("orderDetailsTable.do")
    public TableResultResponse orderDetailsTable(String orderId) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        OrderDetails orderDetails = new OrderDetails();
        orderDetails.setOrderId(orderId);
        List<OrderDetails> orderDetailsList = orderService.selectPage(orderDetails);
        for (OrderDetails record : orderDetailsList) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("name", record.getProductName());
            resultMap.put("avatar", record.getProductImg());
            resultMap.put("price", record.getProductPrice());
            resultMap.put("color", record.getProductParam());
            resultMap.put("number", record.getProductNum());
            infoList.add(resultMap);
        }
        return Result.tableResule(0, infoList);
    }

    /**
     * 付款页面
     *
     * @param mv
     * @return
     */
    @RequestMapping("/toPayPage.do")
    public ModelAndView toPayPage(ModelAndView mv, String id, String price) {
        CommonMethods("no", mv);
        mv.addObject("id", id);
        mv.addObject("price", price);
        mv.setViewName("/front/toPayPage");
        return mv;
    }

    /**
     * 支付
     *
     * @param id
     * @param payPass
     * @return
     */
    @ResponseBody
    @PostMapping("/toPay.do")
    public ResultResponse toPay(String id, String payPass, String balance, Float price) {
        //首页判断支付密码是否正确
        User user = userService.selectByPrimaryKey(itdragonUtils.getSessionUser().getId());
        if (!payPass.equals(user.getPayPass())) {
            return Result.resuleError("支付密码不正确!");
        }
        if ("on".equals(balance)) {
            if (price > user.getBalance()) {
                return Result.resuleError("余额不足!请充值");
            }
        }
        boolean b = orderService.toPay(id);
        if (b) {
            if ("on".equals(balance)) {
                //扣除余额
                OrderFrom orderFrom = orderService.getOrderFrom(id);
                user.setBalance(user.getBalance() - orderFrom.getPrice());
                userService.updateByPrimaryKey(user);
            }
            return Result.resuleSuccess();
        }
        return Result.resuleError("支付失败!");
    }

    /**
     * 提醒发货
     *
     * @param orderId
     * @return
     */
    @ResponseBody
    @PostMapping("/remind.do")
    public ResultResponse remind(String orderId) {
        //首先判断是否已经提醒过
        List<Logistics> remind = orderService.getRemind(orderId, "remind");
        if (!remind.isEmpty()) {
            return Result.resuleError("已经提醒过啦!");
        }
        boolean b = orderService.remind(orderId);
        if (b) {
            return Result.resuleSuccess();
        }
        return Result.resuleError("提醒失败!");
    }

    /**
     * 评价页面
     *
     * @param mv
     * @return
     */
    @RequestMapping("/evaluatePage.do")
    public ModelAndView evaluatePage(ModelAndView mv, String orderId) {
        mv.addObject("orderId", orderId);
        mv.setViewName("/front/evaluate");
        return mv;
    }

    /**
     * 评价
     *
     * @param orderId
     * @return
     */
    @ResponseBody
    @PostMapping("/addEvaluate.do")
    public ResultResponse addEvaluate(String orderId, String content, String score) {
        boolean b = orderService.addEvaluate(orderId, content, score);
        if (b) {
            return Result.resuleSuccess();
        }
        return Result.resuleError("评价失败!");
    }

    /**
     * 退款页面
     *
     * @param mv
     * @return
     */
    @RequestMapping("/salesReturnPage.do")
    public ModelAndView salesReturnPage(ModelAndView mv, String orderId) {
        mv.addObject("orderId", orderId);
        mv.setViewName("/front/salesReturn");
        return mv;
    }

    /**
     * 退款
     *
     * @param orderId
     * @return
     */
    @ResponseBody
    @PostMapping("/salesReturn.do")
    public ResultResponse salesReturn(String orderId, String content) {
        boolean b = orderService.salesReturn(orderId, content);
        if (b) {
            return Result.resuleSuccess();
        }
        return Result.resuleError("提交失败!");
    }

    /**
     * 商品总数查询ajax
     *
     * @param
     * @return
     */
    @ResponseBody
    @PostMapping("/countAjax.do")
    public Integer countAjax(String classifyId, String chdClassId) {
        Product product = new Product();
        product.setChdClassId(chdClassId);
        Integer count = productService.getCount(classifyId, chdClassId);
        return count;
    }

    /**
     * 商品列表异步加载
     *
     * @param
     * @return
     */
    @ResponseBody
    @PostMapping("/productAjax.do")
    public ResultResponse productAjax(Product product, Integer page, Integer limit) {
        Page<Product> productPage = productService.selectPage(product, page, limit);
        if (productPage.getRecords().isEmpty()) {
            return Result.resuleError("暂无数据");
        }
        return Result.resuleSuccess(productPage.getRecords(), "");
    }


    /**
     * 前端页面有一些公用需求在这里抽取出来
     *
     * @param which 是选中哪一个页面顶部标签参数
     * @param mv
     */
    public void CommonMethods(String which, ModelAndView mv) {
        //判断用户是否登录
        boolean gogin = itdragonUtils.isGogin();
        boolean admin = false;
        if (gogin) {
            //如果登录将用户信息放入前台
            mv.addObject("userInfo", userService.selectByPrimaryKey(itdragonUtils.getSessionUser().getId()));
            //平且判断是否是管理员
            admin = userService.isAdmin(itdragonUtils.getSessionUser().getId());

        }
        mv.addObject("go_in", gogin);
        mv.addObject("admin", admin);
        //网站参数
        WbeParameter wbeParameter = wbeParameterService.getWbeParameter();
        mv.addObject("wbeParameter", wbeParameter);
        //商品分类集合
        List<Classify> classifyList = classifyService.selectList();
        mv.addObject("classifyList", classifyList);
        //页面顶部标签高亮判断
        switch (which) {
            case "index":
                mv.addObject("indexClass", "layui-nav-item layui-this");
                mv.addObject("aboutWeClass", "layui-nav-item");
                mv.addObject("leaveWordClass", "layui-nav-item");
                mv.addObject("news", "layui-nav-item");
                mv.addObject("productListClass", "layui-nav-item");
                mv.addObject("likeList", "layui-nav-item");
                break;
            case "aboutWe":
                mv.addObject("indexClass", "layui-nav-item");
                mv.addObject("aboutWeClass", "layui-nav-item layui-this");
                mv.addObject("leaveWordClass", "layui-nav-item");
                mv.addObject("news", "layui-nav-item");
                mv.addObject("productListClass", "layui-nav-item");
                mv.addObject("likeList", "layui-nav-item");
                break;
            case "leaveWord":
                mv.addObject("indexClass", "layui-nav-item");
                mv.addObject("aboutWeClass", "layui-nav-item");
                mv.addObject("leaveWordClass", "layui-nav-item layui-this");
                mv.addObject("news", "layui-nav-item");
                mv.addObject("productListClass", "layui-nav-item");
                mv.addObject("likeList", "layui-nav-item");
                break;
            case "news":
                mv.addObject("indexClass", "layui-nav-item");
                mv.addObject("aboutWeClass", "layui-nav-item");
                mv.addObject("leaveWordClass", "layui-nav-item");
                mv.addObject("news", "layui-nav-item layui-this");
                mv.addObject("productListClass", "layui-nav-item");
                mv.addObject("likeList", "layui-nav-item");
                break;
            case "productList":
                mv.addObject("indexClass", "layui-nav-item");
                mv.addObject("aboutWeClass", "layui-nav-item");
                mv.addObject("leaveWordClass", "layui-nav-item");
                mv.addObject("news", "layui-nav-item");
                mv.addObject("productListClass", "layui-nav-item  layui-this");
                mv.addObject("likeList", "layui-nav-item");
                break;
            case "no":
                mv.addObject("indexClass", "layui-nav-item");
                mv.addObject("aboutWeClass", "layui-nav-item");
                mv.addObject("leaveWordClass", "layui-nav-item");
                mv.addObject("news", "layui-nav-item");
                mv.addObject("productListClass", "layui-nav-item");
                mv.addObject("likeList", "layui-nav-item");
                break;
            case "likeList":
                mv.addObject("indexClass", "layui-nav-item");
                mv.addObject("aboutWeClass", "layui-nav-item");
                mv.addObject("leaveWordClass", "layui-nav-item");
                mv.addObject("news", "layui-nav-item");
                mv.addObject("productListClass", "layui-nav-item");
                mv.addObject("likeList", "layui-nav-item layui-this");
                break;
            default:
        }
    }
}
