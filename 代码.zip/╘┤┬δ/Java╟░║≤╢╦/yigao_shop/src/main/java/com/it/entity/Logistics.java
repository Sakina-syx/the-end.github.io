package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 物流信息
 *
 * @author itdragon
 */
@Data
@TableName("gm_logistics")
public class Logistics implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 订单id
     */
    private String orderId;
    /**
     * 内容
     */
    private String content;
    /**
     * 类型
     */
    private String type;

    private String time;


}