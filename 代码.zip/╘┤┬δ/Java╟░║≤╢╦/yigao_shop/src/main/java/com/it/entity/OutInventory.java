package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 库存实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_outInventory")
public class OutInventory implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 商品名称
     */
    private String productName;
    /**
     * 商品uuId
     */
    private String productUuid;
    /**
     * 数量
     */
    private Integer number;
    /**
     * 单价
     */
    private float unitPrice;
    /**
     * 合计
     */
    private float totalPrice;
    /**
     * 时间
     */
    private String time;
    /**
     * 操作人
     */
    private String userName;

}