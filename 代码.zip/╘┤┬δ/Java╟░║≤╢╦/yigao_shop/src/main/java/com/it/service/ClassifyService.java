package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.ChdClassify;
import com.it.entity.Classify;

import java.util.List;

public interface ClassifyService {
    /**
     * 分页查询
     *
     * @param classify
     * @param page
     * @param limit
     * @return
     */
    Page<Classify> selectPage(Classify classify, int page, int limit);

    /**
     * 新增
     *
     * @param classify
     * @return
     */
    boolean insert(Classify classify);

    /**
     * 删除
     */
    boolean delById(String id);

    /**
     * 得到商品分类集合
     *
     * @return
     */
    List<Classify> selectList();

    /**
     * 新增子分类
     *
     * @param chdClassify
     * @return
     */
    boolean insert(ChdClassify chdClassify);

    /**
     * 删除子分类
     */
    boolean deChdClassifylById(String id);

    /**
     * 得到商品子分类集合
     *
     * @return
     */
    List<ChdClassify> selectChdClassifyList(String ptId);
    List<ChdClassify> selectChdClassifyList();

    Classify getClassify(String id);

    ChdClassify getChdClassify(String id);


}
