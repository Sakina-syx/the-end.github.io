package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 订单详情实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_orderDetails")
public class OrderDetails implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 订单id
     */
    private String orderId;
    /**
     * 商品名称
     */
    private String productId;
    private String productName;
    /**
     * 商品价格
     */
    private Float productPrice;
    /**
     * 商品图片
     */
    private String productImg;
    /**
     * 商品参数
     */
    private String productParam;
    /**
     * 商品数目
     */
    private Integer productNum;
    /**
     * 是否成交
     */
    private String status;
}