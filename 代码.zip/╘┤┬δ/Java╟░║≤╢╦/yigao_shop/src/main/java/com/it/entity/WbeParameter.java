package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 网站参数实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_wbeParameter")
public class WbeParameter implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * logo设置
     */
    private String logo;
    /**
     * name
     */
    private String name;
    /**
     * 热销推荐数
     */
    private String hotNumber;
    /**
     * 新品推荐数
     */
    private String newNumber;
    /**
     * 底部推荐语1
     */
    private String recommendOne;
    /**
     * 底部推荐语2
     */
    private String recommendTwo;
    /**
     * 底部推荐语3
     */
    private String recommendThree;
    /**
     * 首页底部图片
     */
    private String bottomImg;
    /**
     * 登录注册页面背景图
     */
    private String backgroundImg;
    /**
     * 客服电话
     */
    private String iphone;
    /**
     * 关于我们
     */
    private String aboutWe;
    /**
     * 版本号
     */
    private String code;
    /**
     * 域名
     */
    private String yu;
    /**
     * 版权
     */
    private String copyright;
    /**
     * 版权年限
     */
    private String year;
    /**
     * 阈值
     */
    private Integer threshold;
}