package com.it.controller;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Inventory;
import com.it.entity.OutInventory;
import com.it.entity.Product;
import com.it.service.InventoryService;
import com.it.service.ProductService;
import com.it.util.Result;
import com.it.util.ResultResponse;
import com.it.util.TableResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈库存实现接口〉<br>
 *
 * @author
 * @create 2019/1/16 16:00
 * @since 1.0.0
 */
@Controller
@RequestMapping("/inventory")
public class InventoryController {
    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private ProductService productService;

    /**
     * 库存管理界面跳转
     *
     * @param mv
     * @return
     */
    @RequestMapping("/index.do")
    public ModelAndView enIndex(ModelAndView mv) {
        mv.setViewName("inventory/index");
        return mv;
    }

    /**
     * 出库管理界面跳转
     *
     * @param mv
     * @return
     */
    @RequestMapping("/outInventoryIndex.do")
    public ModelAndView outInventoryIndex(ModelAndView mv) {
        mv.setViewName("inventory/outInventoryIndex");
        return mv;
    }

    /**
     * 库存列表加载接口
     *
     * @param inventory
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("inventoryTable.do")
    public TableResultResponse inventoryTable(Inventory inventory, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<Inventory> pageInfo = inventoryService.selectPage(inventory, page, limit);
        for (Inventory record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("productName", record.getProductName());
            resultMap.put("productUuid", record.getProductUuid());
            resultMap.put("hasPin", record.getHasPin());
            resultMap.put("stock", record.getStock());
            resultMap.put("orderNum", record.getOrderNum());
            resultMap.put("userName", record.getUserName());
            resultMap.put("content", record.getContent());
            resultMap.put("time", record.getTime() == null ? "" : record.getTime().substring(0, 19));
            resultMap.put("totalPrice", record.getTotalPrice());
            resultMap.put("unitPrice", record.getUnitPrice());
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 出库列表加载接口
     *
     * @param outInventory
     * @param page
     * @param limit
     * @return
     */
    @ResponseBody
    @GetMapping("outInventoryTable.do")
    public TableResultResponse outInventoryTable(OutInventory outInventory, int page, int limit) {
        List<Map<String, Object>> infoList = new ArrayList<>();
        Page<OutInventory> pageInfo = inventoryService.selectPage(outInventory, page, limit);
        for (OutInventory record : pageInfo.getRecords()) {
            Map<String, Object> resultMap = new HashMap<>(16);
            resultMap.put("id", record.getId());
            resultMap.put("productName", record.getProductName());
            resultMap.put("productUuid", record.getProductUuid());
            resultMap.put("number", record.getNumber());
            resultMap.put("userName", record.getUserName());
            resultMap.put("time", record.getTime() == null ? "" : record.getTime().substring(0, 19));
            resultMap.put("totalPrice", record.getTotalPrice());
            resultMap.put("unitPrice", record.getUnitPrice());
            infoList.add(resultMap);
        }
        return Result.tableResule(pageInfo.getTotal(), infoList);
    }

    /**
     * 删除库存信息
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/inventory.do")
    public ResultResponse delInventory(String id) {
        boolean result = inventoryService.delById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 删除出库信息
     *
     * @param id
     * @return
     */
    @ResponseBody
    @DeleteMapping("/outInventory.do")
    public ResultResponse delOutInventory(String id) {
        boolean result = inventoryService.delOutInventoryById(id);
        if (!result) {
            return Result.resuleError("删除失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 新增库存界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/addInventory.do")
    public ModelAndView addInventory(ModelAndView mv) {
        mv.setViewName("inventory/addInventory");
        return mv;
    }

    /**
     * 新增库存
     *
     * @param inventory
     * @return
     */
    @ResponseBody
    @PostMapping("/inventory.do")
    public ResultResponse insertClassify(Inventory inventory) {
        //通过商品编号查询商品不存在返回false
        Product product = productService.getOneByuuId(inventory.getProductUuid());
        if (product == null) {
            return Result.resuleError("商品不存在!");
        }
        List<Inventory> oneByProductuuId = inventoryService.getOneByProductuuId(inventory.getProductUuid());
        if (!oneByProductuuId.isEmpty()) {
            return Result.resuleError("商品已入库!");
        }
        inventory.setProductName(product.getName());
        inventory.setUnitPrice(product.getPrice());
        inventory.setProductId(product.getId());
        inventory.setHasPin(0);
        inventory.setTotalPrice(product.getPrice() * inventory.getStock());
        boolean result = inventoryService.insert(inventory);
        if (!result) {
            return Result.resuleError("新增失败");
        }
        return Result.resuleSuccess();
    }

    /**
     * 修改库存界面跳转接口
     *
     * @param mv
     * @return
     */
    @RequestMapping("/editInventory.do")
    public ModelAndView editInventory(ModelAndView mv, String id) {
        mv.addObject("inventory", inventoryService.getOneById(id));
        mv.setViewName("inventory/editInventory");
        return mv;
    }

    /**
     * 修改库存
     *
     * @param inventory
     * @return
     */
    @ResponseBody
    @PutMapping("/inventory.do")
    public ResultResponse updataClassify(Inventory inventory) {
        Inventory oneById = inventoryService.getOneById(inventory.getId());
        inventory.setTotalPrice(inventory.getStock() * oneById.getUnitPrice());
        inventory.setUnitPrice(oneById.getUnitPrice());
        inventory.setHasPin(oneById.getHasPin());
        boolean result = inventoryService.edit(inventory);
        if (!result) {
            return Result.resuleError("修改失败");
        }
        return Result.resuleSuccess();
    }

}