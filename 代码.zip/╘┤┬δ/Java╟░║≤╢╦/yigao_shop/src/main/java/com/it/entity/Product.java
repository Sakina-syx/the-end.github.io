package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 商品实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_product")
public class Product implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 商品编号
     */
    private String uuId;
    @TableField(exist = false)
    /**
     * 商品码
     */
    private String code;
    /**
     * 商品名称
     */
    private String name;
    /**
     * 商品图
     */
    private String img;
    /**
     * 价格
     */
    private Float price;
    @TableField(exist = false)
    /**
     * 最低价格
     */
    private Float minPrice;
    @TableField(exist = false)
    /**
     * 最高价格
     */
    private Float maxPrice;
    /**
     * 上架时间
     */
    private String createTime;
    /**
     * 折扣
     */
    private Float discount;
    /**
     * 商品参数
     */
    private String parameter;
    /**
     * 商品参数
     */
    @TableField(exist = false)
    private String[] parameters;
    /**
     * 详情
     */
    private String particulars;
    /**
     * 商品父类id
     */
    private String classifyId;
    /**
     * 商品子类id
     */
    private String chdClassId;
    /**
     * 排序字段
     */
    @TableField(exist = false)
    private String orderParam;
    /**
     * 是否收藏
     */
    @TableField(exist = false)
    private boolean collect;
    /**
     * 库存数
     */
    @TableField(exist = false)
    private Integer inventoryData;
    @TableField(exist = false)
    private Integer saleNumber;

}