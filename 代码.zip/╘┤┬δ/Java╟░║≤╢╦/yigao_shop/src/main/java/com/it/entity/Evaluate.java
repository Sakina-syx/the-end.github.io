package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 商品评价实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_evaluate")
public class Evaluate implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 用户
     */
    private String userName;
    /**
     * 用户头像
     */
    private String img;
    /**
     * 商品id
     */
    private String productId;
    /**
     * 评价信息
     */
    private String content;
    /**
     * 评价分数
     */
    private String score;
    /**
     * 评价时间
     */
    private String time;


}