package com.it.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Inventory;
import com.it.entity.OutInventory;
import com.it.mapper.InventoryMapper;
import com.it.mapper.OutInvrntoryMapper;
import com.it.service.InventoryService;
import com.it.util.DateUtil;
import com.it.util.ItdragonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 〈库存实现接口〉<br>
 *
 * @author
 * @create 2019/2/15 17:53
 * @since 1.0.0
 */
@Service
public class InventoryServiceImpl implements InventoryService {
    @Resource
    private ItdragonUtils itdragonUtils;
    @Resource
    private InventoryMapper inventoryMapper;
    @Resource
    private OutInvrntoryMapper outInvrntoryMapper;

    @Override
    public Page<Inventory> selectPage(Inventory inventory, int page, int limit) {
        EntityWrapper<Inventory> searchInfo = new EntityWrapper<>();
        Page<Inventory> pageInfo = new Page<>(page, limit);
        if (ItdragonUtils.stringIsNotBlack(inventory.getProductName())) {
            searchInfo.eq("productName", inventory.getProductName());
        }
        if (ItdragonUtils.stringIsNotBlack(inventory.getProductUuid())) {
            searchInfo.eq("productUuid", inventory.getProductUuid());
        }
        List<Inventory> resultList = inventoryMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public Page<OutInventory> selectPage(OutInventory outInventory, int page, int limit) {
        EntityWrapper<OutInventory> searchInfo = new EntityWrapper<>();
        Page<OutInventory> pageInfo = new Page<>(page, limit);
        if (ItdragonUtils.stringIsNotBlack(outInventory.getProductName())) {
            searchInfo.eq("productName", outInventory.getProductName());
        }
        if (ItdragonUtils.stringIsNotBlack(outInventory.getProductUuid())) {
            searchInfo.eq("productUuid", outInventory.getProductUuid());
        }
        List<OutInventory> resultList = outInvrntoryMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insert(Inventory inventory) {
        inventory.setTime(DateUtil.getNowDateSS());
        inventory.setUserName(itdragonUtils.getSessionUser().getUserName());
        Integer insert = inventoryMapper.insert(inventory);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean insert(OutInventory outInventory) {
        outInventory.setTime(DateUtil.getNowDateSS());
        outInventory.setUserName(itdragonUtils.getSessionUser().getUserName());
        Integer insert = outInvrntoryMapper.insert(outInventory);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean delById(String id) {
        Integer delete = inventoryMapper.deleteById(id);
        if (delete > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean delOutInventoryById(String id) {
        Integer delete = outInvrntoryMapper.deleteById(id);
        if (delete > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean edit(Inventory inventory) {
        Integer insert = inventoryMapper.updateById(inventory);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public Inventory getOneById(String id) {
        return inventoryMapper.selectById(id);
    }

    @Override
    public List<Inventory> getOneByProductuuId(String productuuId) {
        EntityWrapper<Inventory> wrapper = new EntityWrapper<>();
        wrapper.eq("productUuid", productuuId);
        List<Inventory> selectList = inventoryMapper.selectList(wrapper);
        return selectList;
    }

    @Override
    public List<Inventory> getOneByProductId(String productId) {
        EntityWrapper<Inventory> wrapper = new EntityWrapper<>();
        wrapper.eq("productId", productId);
        List<Inventory> selectList = inventoryMapper.selectList(wrapper);
        return selectList;
    }

    @Override
    public boolean editStock(String productId, Integer number) {
        EntityWrapper<Inventory> wrapper = new EntityWrapper<>();
        wrapper.eq("productId", productId);
        List<Inventory> inventories = inventoryMapper.selectList(wrapper);
        Inventory selectOne = inventories.get(0);
        selectOne.setHasPin(selectOne.getHasPin() + number);
        selectOne.setStock(selectOne.getStock() - number);
        Integer integer = inventoryMapper.updateById(selectOne);
        if (integer > 0) {
            return true;
        }
        return false;

    }

}