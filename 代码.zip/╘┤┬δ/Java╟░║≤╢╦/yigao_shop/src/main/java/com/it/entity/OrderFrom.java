package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 订单实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_orderFrom")
public class OrderFrom implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 用户id
     */
    private String userId;
    /**
     * 订单uuId
     */
    private String uuId;
    /**
     * 收货人详情
     */
    private String address;
    /**
     * 订单总金额
     */
    private Float price;
    /**
     * 创建时间
     */
    private String time;
    /**
     * 状态
     */
    private String status;
    /**
     * 配送方式
     */
    private String mode;
    /**
     * 备注
     */
    private String content;
}