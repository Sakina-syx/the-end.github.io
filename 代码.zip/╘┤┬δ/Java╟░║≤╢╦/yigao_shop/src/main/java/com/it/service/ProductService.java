package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.Collect;
import com.it.entity.Product;
import com.it.entity.Trolley;

import java.util.List;

public interface ProductService {
    /**
     * 分页查询
     *
     * @param product
     * @param page
     * @param limit
     * @return
     */
    Page<Product> selectPage(Product product, int page, int limit);

    /**
     * 新增
     *
     * @param product
     * @return
     */
    boolean insert(Product product);

    /**
     * 删除
     */
    boolean delById(String id);

    /**
     * 编辑
     */
    boolean editById(Product product);

    /**
     * 根据id得到单个商品
     */
    Product getOne(String id);

    /**
     * 根据uuid得到单个商品
     */
    Product getOneByuuId(String uuId);

    /**
     * 根据父子分类id查询商品数目
     *
     * @param chdClassId
     * @param classifyId
     * @return
     */
    Integer getCount(String classifyId, String chdClassId);

    /**
     * 收藏分页查询
     *
     * @param collect
     * @param page
     * @param limit
     * @return
     */
    Page<Collect> selectCollectPage(Collect collect, int page, int limit);

    /**
     * 新增收藏
     *
     * @param collect
     * @return
     */
    boolean insertCollect(Collect collect);

    /**
     * 删除收藏
     */
    boolean delCollectById(String id);
    /**
     * 判断用户是否收藏该商品
     */
    boolean isCollect(String productId);

    /**
     * 添加到购物车
     *
     * @param trolley
     * @return
     */
    boolean insertTrolley(Trolley trolley);

    /**
     * 获取购物车集合
     * @param userId
     * @return
     */
    List<Trolley> getTrolleyList(String userId);

    /**
     * 获取商品集合
     * @return
     */
    List<Product> getProductList();
    List<Product> getProductListOrderByTime();
    List<Product> getProductListOrderSlae();

}
