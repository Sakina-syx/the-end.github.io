package com.it.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;

import java.io.Serializable;

/**
 * 收货地址实体类
 *
 * @author itdragon
 */
@Data
@TableName("gm_address")
public class Address implements Serializable {
    /**
     * 自增长主键
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 用户id
     */
    private String userId;
    /**
     * 省市区
     */
    private String cityPicker;
    /**
     * 详细地址
     */
    private String detailAddress;
    /**
     * 收货人
     */
    private String consignee;
    private String phone;
    /**
     * 是否默认
     */
    private String isDefault;

}