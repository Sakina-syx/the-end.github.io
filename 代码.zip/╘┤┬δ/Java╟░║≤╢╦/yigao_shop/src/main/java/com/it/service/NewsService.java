package com.it.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.News;
import com.it.entity.Slideshow;

import java.util.List;

public interface NewsService {
    /**
     * 分页查询
     *
     * @param news
     * @param page
     * @param limit
     * @return
     */
    Page<News> selectPage(News news, int page, int limit);

    /**
     * 新增
     *
     * @param news
     * @return
     */
    boolean insert(News news);

    /**
     * 删除
     */
    boolean delById(String id);

    boolean editById(News news);

    News getOneById(String id);


}
