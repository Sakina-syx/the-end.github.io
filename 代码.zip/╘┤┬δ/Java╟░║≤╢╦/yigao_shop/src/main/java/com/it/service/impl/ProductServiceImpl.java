package com.it.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.it.entity.*;
import com.it.mapper.*;
import com.it.service.ProductService;
import com.it.util.DateUtil;
import com.it.util.ItdragonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    @Resource
    private ProductMapper productMapper;
    @Resource
    private ItdragonUtils itdragonUtils;
    @Resource
    private InventoryMapper inventoryMapper;
    @Resource
    private CollectMapper collectMapper;
    @Resource
    private TrolleyMapper trolleyMapper;
    @Resource
    private OrderDetailsMapper orderDetailsMapper;

    @Override
    public Page<Product> selectPage(Product product, int page, int limit) {
        EntityWrapper<Product> searchInfo = new EntityWrapper<>();
        if (ItdragonUtils.stringIsNotBlack(product.getUuId())) {
            searchInfo.eq("uuId", product.getUuId());
        }
        if (ItdragonUtils.stringIsNotBlack(product.getName())) {
            searchInfo.like("name", product.getName());
        }
        if (ItdragonUtils.stringIsNotBlack(product.getClassifyId())) {
            searchInfo.eq("classifyId", product.getClassifyId());
        }
        if (ItdragonUtils.stringIsNotBlack(product.getChdClassId())) {
            searchInfo.eq("chdClassId", product.getChdClassId());
        }
        if (product.getMinPrice() != null) {
            searchInfo.between("price", product.getMinPrice(), product.getMaxPrice());
        }
        if (ItdragonUtils.stringIsNotBlack(product.getCreateTime())) {
            searchInfo.between("createTime", product.getCreateTime().split(" ~ ")[0], product.getCreateTime().split(" ~ ")[1]);
        }
        if (ItdragonUtils.stringIsNotBlack(product.getOrderParam())) {
            searchInfo.orderBy(product.getOrderParam());
        }
        Page<Product> pageInfo = new Page<>(page, limit);
        List<Product> resultList = productMapper.selectPage(pageInfo, searchInfo);
        for (Product product1 : resultList) {
            EntityWrapper<OrderDetails> wrapper = new EntityWrapper<>();
            wrapper.eq("productId", product1.getId());
            List<OrderDetails> orderDetailsList = orderDetailsMapper.selectList(wrapper);
            product1.setSaleNumber(orderDetailsList.size());
        }
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insert(Product product) {
        product.setUuId(itdragonUtils.getProductUUId(product.getCode()));
        product.setCreateTime(DateUtil.getNowDateSS());
        Integer insert = productMapper.insert(product);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean delById(String id) {
        //删除商品同时删除库存数据
        EntityWrapper<Inventory> wrapper = new EntityWrapper<>();
        wrapper.eq("productId", id);
        inventoryMapper.delete(wrapper);
        //删除商品同时删除购物车数据
        EntityWrapper<Trolley> wrapperTrolley = new EntityWrapper<>();
        wrapperTrolley.eq("productId", id);
        trolleyMapper.delete(wrapperTrolley);
        //删除商品同时删除收藏数据
        EntityWrapper<Collect> wrapperCollect = new EntityWrapper<>();
        wrapperCollect.eq("productId", id);
        collectMapper.delete(wrapperCollect);
        Integer delete = productMapper.deleteById(id);
        if (delete > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean editById(Product product) {
        Integer update = productMapper.updateById(product);
        if (update > 0) {
            return true;
        }
        return false;
    }

    @Override
    public Product getOne(String id) {
        return productMapper.selectById(id);

    }

    @Override
    public Product getOneByuuId(String uuId) {
        Product product = new Product();
        product.setUuId(uuId);
        Product one = productMapper.selectOne(product);
        return one;
    }

    @Override
    public Integer getCount(String classifyId, String chdClassId) {
        EntityWrapper<Product> wrapper = new EntityWrapper<>();
        if (ItdragonUtils.stringIsNotBlack(classifyId)) {
            wrapper.eq("classifyId", classifyId);
        }
        if (ItdragonUtils.stringIsNotBlack(chdClassId)) {
            wrapper.eq("chdClassId", chdClassId);
        }
        List<Product> productList = productMapper.selectList(wrapper);
        return productList.size();
    }

    @Override
    public Page<Collect> selectCollectPage(Collect collect, int page, int limit) {
        EntityWrapper<Collect> searchInfo = new EntityWrapper<>();
        searchInfo.eq("userId", itdragonUtils.getSessionUser().getId());
        Page<Collect> pageInfo = new Page<>(page, limit);
        List<Collect> resultList = collectMapper.selectPage(pageInfo, searchInfo);
        if (!resultList.isEmpty()) {
            pageInfo.setRecords(resultList);
        }
        return pageInfo;
    }

    @Override
    public boolean insertCollect(Collect collect) {
        Product product = productMapper.selectById(collect.getProductId());
        collect.setProductName(product.getName());
        collect.setProductPrice(product.getPrice());
        collect.setProductImg(product.getImg());
        collect.setUserId(itdragonUtils.getSessionUser().getId());
        Integer insert = collectMapper.insert(collect);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean delCollectById(String id) {
        Integer insert = collectMapper.deleteById(id);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isCollect(String productId) {
        Collect collect = new Collect();
        collect.setUserId(itdragonUtils.getSessionUser().getId());
        collect.setProductId(productId);
        Collect collect1 = collectMapper.selectOne(collect);
        if (collect1 == null) {
            return false;
        }
        return true;
    }

    @Override
    public boolean insertTrolley(Trolley trolley) {
        trolley.setUserId(itdragonUtils.getSessionUser().getId());
        Integer insert = trolleyMapper.insert(trolley);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    @Override
    public List<Trolley> getTrolleyList(String userId) {
        EntityWrapper<Trolley> wrapper = new EntityWrapper<>();
        wrapper.eq("userId", userId);
        List<Trolley> trolleyList = trolleyMapper.selectList(wrapper);
        return trolleyList;
    }

    @Override
    public List<Product> getProductList() {
        List<Product> products = productMapper.selectList(null);
        return products;
    }

    @Override
    public List<Product> getProductListOrderByTime() {
        EntityWrapper<Product> wrapper = new EntityWrapper<>();
        wrapper.orderBy("createTime desc");
        List<Product> productList = productMapper.selectList(wrapper);
        return productList;

    }

    @Override
    public List<Product> getProductListOrderSlae() {
        List<Product> productList = productMapper.selectList(null);
        for (Product product : productList) {
            EntityWrapper<OrderDetails> wrapper = new EntityWrapper<>();
            wrapper.eq("productId", product.getId());
            List<OrderDetails> orderDetailsList = orderDetailsMapper.selectList(wrapper);
            product.setSaleNumber(orderDetailsList.size());
        }
        Collections.sort(productList, new Comparator<Product>() {
            @Override
            public int compare(Product o1, Product o2) {
                //升序
                return o2.getSaleNumber().compareTo(o1.getSaleNumber());
            }
        });
        return productList;
    }
}
